# Postale

Simple wrapper around `smtplib` and `email` libraries.
